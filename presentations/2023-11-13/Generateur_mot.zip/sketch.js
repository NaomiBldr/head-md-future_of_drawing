let realWords = [
  "apple", "banana", "carrot", "dog", "elephant", "flower", "guitar", "house", "island", "jacket",
  "kangaroo", "lemon", "mountain", "notebook", "ocean", "piano", "quilt", "rainbow", "sunflower", "tree",
  "umbrella", "violin", "waterfall", "xylophone", "yogurt", "zebra", "book", "computer", "desk", "keyboard",
  "lamp", "mirror", "orange", "penguin", "queen", "robot", "snake", "turtle", "vase", "wagon", "xylograph",
  "yard", "zipper", "butterfly", "castle", "diamond", "fireworks", "giraffe", "hamburger", "icecream", "jellyfish",
  "kite", "lighthouse", "moon", "nebula", "octopus", "puzzle", "quasar", "rocket", "sailboat", "telescope",
  "umbrella", "volcano", "whale", "xylograph", "yarn", "zeppelin", "astronaut", "balloon", "compass", "dolphin",
  "eclipse", "fountain", "glacier", "helicopter", "igloo", "jigsaw", "kayak", "laser", "monument", "nightingale",
  "opera", "parachute", "quilt", "rollercoaster", "spaceship", "tornado", "underwater", "volcano", "waffle", "xylophonist",
  "yellowstone", "zipper", "astronomy", "breathtaking", "conversation", "discovery", "elephantiasis", "fantastic", "giraffes", "holographic"
];

let currentWord = "";

function setup() {
  createCanvas(400, 200);
  textAlign(CENTER, CENTER);
  textSize(32);
  generateRandomWord();
}

function draw() {
  background(220);
  fill(0);
  text(currentWord, width / 2, height / 2);
}

function generateRandomWord() {
  // Randomly choose a word from the list
  currentWord = random(realWords);
}

function mousePressed() {
  generateRandomWord();
}