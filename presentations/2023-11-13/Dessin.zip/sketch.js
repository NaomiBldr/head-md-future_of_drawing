let blobs = [];
let lastBlobTime = 0;
let paths = [];
let currentPath = [];

function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(255);

  // Dessine les formes existantes
  for (let i = 0; i < blobs.length; i++) {
    let blob = blobs[i];
    drawBlob(blob.x, blob.y, blob.color, blob.radius);
  }

  // Dessine les tracés noirs
  for (let i = 0; i < paths.length; i++) {
    let path = paths[i];
    drawPath(path);
  }

  // Dessine le tracé noir à la souris
  if (mouseIsPressed && mouseButton === LEFT) {
    let speed = dist(pmouseX, pmouseY, mouseX, mouseY);
    brushSize = map(speed, 0, 20, 5, 20);

    // Enregistre la position actuelle dans le tableau de la trajectoire
    let point = {
      x: mouseX,
      y: mouseY + scrollY, // Ajuste la position en fonction du défilement
      size: brushSize,
    };
    currentPath.push(point);

    // Dessine le trait continu noir
    drawPath(currentPath);
  } else {
    // Si le bouton n'est pas enfoncé, enregistre le trajet dans le tableau des formes
    if (currentPath.length > 0) {
      paths.push(currentPath.slice()); // Ajoute le tracé actuel à la liste des tracés
      currentPath = []; // Réinitialise le tracé actuel
    }
  }

  // Génère une nouvelle forme à une fréquence moins élevée
  if (mouseIsPressed && millis() - lastBlobTime > 500) {
    let blob = {
      x: random(width),
      y: mouseY + scrollY,
      color: color(random(200, 255), random(200, 255), random(200, 255), 150),
      radius: random(10, 30),
    };
    blobs.push(blob);
    lastBlobTime = millis(); // Enregistre le temps de la dernière génération de forme
  }
}

function drawBlob(x, y, blobColor, radius) {
  noStroke();
  fill(blobColor);
  ellipse(x, y - scrollY, radius * 2, radius * 2);
}

function drawPath(path) {
  stroke(0);
  noFill();
  beginShape();
  for (let i = 0; i < path.length; i++) {
    vertex(path[i].x, path[i].y - scrollY); // Ajuste la position en fonction du défilement
  }
  endShape();
}

function mouseWheel(event) {
  // Défilement de la toile vers le haut ou le bas avec la roulette de la souris
  scrollY += event.delta;
  return false; // Empêche le défilement par défaut de la page
}


